set termout off
set echo off
set feedback off
set verify off
set heading on
set pagesize 0
set linesize 32767
set trimspool on
set markup csv on

spool output_csv/PHASE_6_SQL_REWRITE.csv
select sql_id,
       case
         when instr(upper(sql_text),'TO_CHAR')>0 then 'FUNCTION_ON_COLUMN'
         when instr(upper(sql_text),'||')>0 then 'CONCATENATION'
       end rewrite_flag
from gv$sql
where sql_id='&SQL_ID';
spool off
