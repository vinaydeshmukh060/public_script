set termout off
set echo off
set feedback off
set verify off
set heading on
set pagesize 0
set linesize 32767
set trimspool on
set markup csv on

spool output_csv/PHASE_7_BINDS.csv
select sql_id,
       child_number,
       executions,
       parse_calls,
       is_bind_sensitive,
       is_bind_aware
from gv$sql
where sql_id='&SQL_ID';
spool off
