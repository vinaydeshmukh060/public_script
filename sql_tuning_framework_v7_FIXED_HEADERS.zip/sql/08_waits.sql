set termout off
set echo off
set feedback off
set verify off
set heading on
set pagesize 0
set linesize 32767
set trimspool on
set markup csv on

spool output_csv/PHASE_8_WAITS.csv
select inst_id,
       event,
       wait_class,
       round(time_waited/1e2,2) time_waited_sec
from gv$system_event
where wait_class <> 'Idle';
spool off
