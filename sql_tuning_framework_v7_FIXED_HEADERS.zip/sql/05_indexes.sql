set termout off
set echo off
set feedback off
set verify off
set heading on
set pagesize 0
set linesize 32767
set trimspool on
set markup csv on

spool output_csv/PHASE_5_INDEXES.csv
select owner,
       index_name,
       table_name,
       uniqueness,
       status
from dba_indexes
where table_name in (
  select object_name
  from gv$sql_plan
  where sql_id='&SQL_ID'
);
spool off
